<?php

declare(strict_types=1);

namespace Recall\Http\Controller;

use DateInterval;
use DateTimeImmutable;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Recall\Domain\Stats;
use Recall\Domain\ValueObject\Day;
use Recall\Domain\ValueObject\Interval;
use Recall\Http\Json;
use Recall\Http\Serializer;
use Recall\Infrastructure\Persistence\CardRepository;
use Recall\Infrastructure\Persistence\ReviewRepository;

final readonly class StatsController
{
    public function __construct(
        private CardRepository $cards,
        private ReviewRepository $reviews,
        private Serializer $serializer,
        private DateTimeImmutable $now,
    ) {}

    public function index(Request $request, Response $response): Response
    {
        $today = Day::today($this->now);
        $endOfWeek = $today->plusDays(Interval::ofDays(6));

        // due_today: всё, что пора повторить прямо сейчас (включая просроченное) —
        // та же выборка, что отдаёт /reviews/queue.
        $dueToday = count($this->cards->dueOn($today));

        // due_week: то же самое, но с горизонтом в 7 дней (сегодня + 6 дальше).
        // Просроченные и сегодняшние карточки входят и сюда — поэтому
        // due_week всегда >= due_today.
        $dueWeek = count($this->cards->dueOn($endOfWeek));

        $stats = new Stats(dueToday: $dueToday, dueWeek: $dueWeek, streak: $this->streak());

        return Json::write($response, $this->serializer->serialize($stats));
    }

    /**
     * Серия: число подряд идущих дней с хотя бы одним повторением.
     *
     * Считаем от сегодня назад. Если сегодня повторений ещё не было, серия не
     * сгорает мгновенно в полночь — даём отсчёт от вчера. Если повторений нет
     * ни сегодня, ни вчера, серия прервана.
     */
    private function streak(): int
    {
        $reviewedDays = [];
        foreach ($this->reviews->all() as $review) {
            $reviewedDays[$review->createdAt()->format('Y-m-d')] = true;
        }

        if ($reviewedDays === []) {
            return 0;
        }

        $oneDay = new DateInterval('P1D');
        $cursor = $this->now;
        if (!isset($reviewedDays[$cursor->format('Y-m-d')])) {
            $cursor = $cursor->sub($oneDay);
            if (!isset($reviewedDays[$cursor->format('Y-m-d')])) {
                return 0;
            }
        }

        $streak = 0;
        while (isset($reviewedDays[$cursor->format('Y-m-d')])) {
            $streak++;
            $cursor = $cursor->sub($oneDay);
        }

        return $streak;
    }
}
